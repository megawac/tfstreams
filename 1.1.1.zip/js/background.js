//checks how many streams are live every 60 seconds & updates badge
(function() {
    "use strict";
    var streamURL = "http://teamfortress.tv/rss/streams",
        refreshTime = 60,//s
        parser = new DOMParser();
    //get streams from tf.tv
    function getStreams(fun) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", streamURL, true);
        xhr.onreadystatechange = (function() {
            if (xhr.readyState === 4) { //when retrieved
                //callback
                fun(xhr.responseText);
            }
        });
        xhr.send(); //fetch
    }

    function updateBadge(xml) {
        var doc = parser.parseFromString(xml, 'text/xml'),
            streams = doc.getElementsByTagName('stream');
        chrome.browserAction.setBadgeText({text: (streams.length).toString()}); //update badge
    }

    function refresh () {
        getStreams(updateBadge);
        setTimeout(refresh, refreshTime * 1000);//refresh every min
    }

    (function init () {
        chrome.browserAction.setBadgeBackgroundColor({color: '#D7EFFA'});
        refresh();
    })();
})();